package com.example.responsiveapp.domain.model

import androidx.compose.runtime.Immutable

@Immutable
data class NutritionInfo(
    val calories: Float = 0f,
    val protein: Float = 0f,
    val carbs: Float = 0f,
    val fat: Float = 0f,
    val fiber: Float = 0f,
    val sugar: Float = 0f,
    val sodium: Float = 0f,
    val cholesterol: Float = 0f,
    val saturatedFat: Float = 0f,
    val polyunsaturatedFat: Float = 0f,
    val monounsaturatedFat: Float = 0f,
    val transFat: Float = 0f,
    val potassium: Float = 0f,
    val addedSugars: Float = 0f,
    val vitaminA: Float = 0f,
    val vitaminC: Float = 0f,
    val vitaminD: Float = 0f,
    val calcium: Float = 0f,
    val iron: Float = 0f,
)

fun NutritionInfo.scale(factor: Float) = copy(
    calories = calories * factor,
    protein = protein * factor,
    carbs = carbs * factor,
    fat = fat * factor,
    fiber = fiber * factor,
    sugar = sugar * factor,
    sodium = sodium * factor,
    cholesterol = cholesterol * factor,
    saturatedFat = saturatedFat * factor,
    polyunsaturatedFat = polyunsaturatedFat * factor,
    monounsaturatedFat = monounsaturatedFat * factor,
    transFat = transFat * factor,
    potassium = potassium * factor,
    addedSugars = addedSugars * factor,
    vitaminA = vitaminA * factor,
    vitaminC = vitaminC * factor,
    vitaminD = vitaminD * factor,
    calcium = calcium * factor,
    iron = iron * factor,
)
