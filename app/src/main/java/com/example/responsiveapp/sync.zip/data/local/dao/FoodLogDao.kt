package com.example.responsiveapp.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.responsiveapp.data.local.entity.DailyMealCount
import com.example.responsiveapp.data.local.entity.FoodLogEntity
import com.example.responsiveapp.domain.model.SyncStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface FoodLogDao {

    @Query("""
        SELECT *
        FROM food_logs
        WHERE date = :date
        ORDER BY createdAt DESC
    """)
    fun getFoodLogsForDate(date: Long): Flow<List<FoodLogEntity>>

    @Query("""
        SELECT date, COUNT(*) as count
        FROM food_logs
        WHERE date BETWEEN :startDate AND :endDate
        GROUP BY date
    """)
    fun observeMealCountsBetweenDates(
        startDate: Long,
        endDate: Long,
    ): Flow<List<DailyMealCount>>

    @Query("""
        SELECT DISTINCT date
        FROM food_logs
        ORDER BY date DESC
    """)
    fun observeLoggedDates(): Flow<List<Long>>

    @Query("""
        SELECT *
        FROM food_logs
        WHERE id = :logId
    """)
    suspend fun getFoodLogById(logId: String): FoodLogEntity?

    @Query("""
        SELECT *
        FROM food_logs
        WHERE syncStatus IN ('PENDING', 'FAILED')
        ORDER BY createdAt ASC
    """)
    suspend fun getPending(): List<FoodLogEntity>

    @Query("""
        SELECT COUNT(*)
        FROM food_logs
        WHERE syncStatus = 'PENDING'
    """)
    suspend fun getPendingCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFoodLog(foodLog: FoodLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllFromRemote(foodLogs: List<FoodLogEntity>)

    @Update
    suspend fun updateFoodLog(foodLog: FoodLogEntity)

    @Query("""
        UPDATE food_logs
        SET
            syncStatus = :status,
            lastSyncAttempt = :lastSyncAttempt
        WHERE id = :logId
    """)
    suspend fun updateSyncStatus(
        logId: String,
        status: SyncStatus,
        lastSyncAttempt: Long
    )

    @Query("""
        UPDATE food_logs
        SET
            retryCount = :retryCount,
            lastSyncAttempt = :lastSyncAttempt
        WHERE id = :logId
    """)
    suspend fun updateRetryInfo(
        logId: String,
        retryCount: Int,
        lastSyncAttempt: Long
    )

    @Query("""
        DELETE FROM food_logs
        WHERE id = :logId
    """)
    suspend fun deleteFoodLog(logId: String)

    @Query("""
        DELETE FROM food_logs
    """)
    suspend fun deleteAllLogs()
}