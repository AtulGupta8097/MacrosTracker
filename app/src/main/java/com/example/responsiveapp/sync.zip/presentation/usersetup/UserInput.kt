package com.example.responsiveapp.presentation.usersetup

import com.example.responsiveapp.domain.model.ActivityLevel
import com.example.responsiveapp.domain.model.Gender
import com.example.responsiveapp.domain.model.Goal
import com.example.responsiveapp.domain.model.UserProfile

data class UserInput(
    val name: String? = null,
    val gender: Gender? = null,
    val age: Int? = null,
    val weight: Float? = null,
    val height: Float? = null,
    val activityLevel: ActivityLevel? = null,
    val targetWeight: Float? = null,
    val goal: Goal? = null
)

fun UserInput.toDomain(): UserProfile {
    return UserProfile(
        name = requireNotNull(name).trim(),
        gender = requireNotNull(gender),
        age = requireNotNull(age),
        height = requireNotNull(height),
        weight = requireNotNull(weight),
        activityLevel = requireNotNull(activityLevel),
        targetWeight = requireNotNull(targetWeight),
        goal = requireNotNull(goal)
    )
}
