package com.example.responsiveapp.presentation.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.adaptive.WindowAdaptiveInfo
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf

enum class DeviceConfiguration {
    MOBILE,
    TABLET,
    DESKTOP;

    companion object {

        fun fromAdaptiveInfo(
            adaptiveInfo: WindowAdaptiveInfo
        ): DeviceConfiguration {

            val windowSizeClass = adaptiveInfo.windowSizeClass

            return when {
                windowSizeClass.isWidthAtLeastBreakpoint(840) ->
                    DESKTOP

                windowSizeClass.isWidthAtLeastBreakpoint(600)  ->
                    TABLET

                else ->
                    MOBILE
            }
        }
    }
}
val LocalDeviceConfiguration =
    staticCompositionLocalOf {
        DeviceConfiguration.MOBILE
    }


val MaterialTheme.deviceConfiguration: DeviceConfiguration
    @Composable
    @ReadOnlyComposable
    get() = LocalDeviceConfiguration.current



