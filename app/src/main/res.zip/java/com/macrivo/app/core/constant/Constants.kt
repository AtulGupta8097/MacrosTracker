package com.macrivo.app.core.constant

object Constants {
    const val API_BASE_URL = "https://platform.fatsecret.com/"
    const val OAUTH_BASE_URL = "https://oauth.fatsecret.com/"
    const val TIMEOUT_SECONDS = 30L
}