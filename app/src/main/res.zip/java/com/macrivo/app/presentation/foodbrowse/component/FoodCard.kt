package com.macrivo.app.presentation.foodbrowse.component

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.macrivo.app.domain.model.FoodItem
import com.macrivo.app.domain.model.MacroSummary
import com.macrivo.app.presentation.commoncomponent.CircularIconButton
import com.macrivo.app.presentation.ui.theme.ResponsiveAppTheme
import com.macrivo.app.presentation.ui.theme.spacing
import kotlin.math.roundToInt

@Composable
fun FoodCard(
    modifier: Modifier = Modifier,
    food: FoodItem,
    onFoodClick: () -> Unit,
    isSelected: Boolean = false,
){
    val macros = food.macroSummary

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onFoodClick() },
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surface,
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(MaterialTheme.spacing.md),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.sm),
            ) {
                // Food name + optional brand
                Text(
                    text = food.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                food.brand?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }

                if (macros != null) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.xs),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "${macros.calories.roundToInt()} cal",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "·",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Text(
                            text = "per ${macros.servingLabel}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }

            CircularIconButton(
                icon = Icons.Default.Add,
                contentDescription = "Log meal",
                onClick = onFoodClick
            )
        }
    }
}

@Preview
@Composable
private fun PrevFoodCard() {
    ResponsiveAppTheme {
        FoodCard(
            food = FoodItem(
                id = "1334",
                name = "Pizza",
                brand = "Pizza Hut",
                macroSummary = MacroSummary(
                    servingLabel = "1 slice",
                    calories = 265f,
                    protein = 26f,
                    fat = 2f,
                    carbs = 7f
                )
            ),
            onFoodClick = {},
            isSelected = false
        )
    }
}