package com.macrivo.app.presentation.mainscreen

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.navigation3.rememberViewModelStoreNavEntryDecorator
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import com.macrivo.app.core.navigation.Routes
import com.macrivo.app.presentation.barcode.BarcodeScanScreen
import com.macrivo.app.presentation.fooddatabase.FoodDatabaseScreen
import com.macrivo.app.presentation.fooddatabase.FoodTab
import com.macrivo.app.presentation.home.HomeScreen
import com.macrivo.app.presentation.mainscreen.component.AddFoodBottomSheet
import com.macrivo.app.presentation.mainscreen.component.BottomNav
import com.macrivo.app.presentation.mainscreen.component.Navbar
import com.macrivo.app.presentation.mainscreen.component.SideNav
import com.macrivo.app.presentation.progress.ProgressScreen
import com.macrivo.app.presentation.settings.SettingsScreen
import com.macrivo.app.presentation.ui.theme.DeviceConfiguration
import com.macrivo.app.presentation.ui.theme.deviceConfiguration

@RequiresApi(Build.VERSION_CODES.VANILLA_ICE_CREAM)
@Composable
fun MainScreen(
    onSignedOut: () -> Unit,
    onAccountDeleted: () -> Unit
) {

    val deviceConfig = MaterialTheme.deviceConfiguration
    val navBackStack = rememberNavBackStack(Routes.HomeScreen)

    var showBottomSheet by remember { mutableStateOf(false) }

    val currentRoute = navBackStack.lastOrNull()

    val routesWithBottomBar = listOf(
        Routes.HomeScreen,
        Routes.ProgressScreen,
        Routes.SettingsScreen
    )

    val showBottomBar = currentRoute in routesWithBottomBar

    val navItems = listOf(
        Navbar.Home,
        Navbar.Progress,
        Navbar.Settings,
    )

    val selectedTabIndex =
        navItems.indexOfFirst { it.route == currentRoute }.coerceAtLeast(0)

    when (deviceConfig) {

        DeviceConfiguration.MOBILE -> {
            Scaffold(
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    if (showBottomBar) {
                        BottomNav(
                            items = navItems,
                            selectedTab = selectedTabIndex,
                            onTabSelected = { index ->
                                navBackStack.navigateSingleTop(navItems[index].route)
                            },
                            onAddClick = { showBottomSheet = true },
                        )
                    }
                }
            ) { padding ->
                MainContent(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    navBackStack = navBackStack,
                    onSignedOut = onSignedOut,
                    onAccountDeleted = onAccountDeleted,
                )
            }
        }

        DeviceConfiguration.TABLET,
        DeviceConfiguration.DESKTOP -> {

            Scaffold(
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
            ) { padding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {

                    if (showBottomBar) {
                        SideNav(
                            items = navItems,
                            selectedIndex = selectedTabIndex,
                            onItemSelected = { index ->
                                navBackStack.navigateSingleTop(navItems[index].route)
                            },
                            onAddClick = { showBottomSheet = true },
                        )
                    }

                    MainContent(
                        modifier = Modifier.weight(1f),
                        navBackStack = navBackStack,
                        onSignedOut = onSignedOut,
                        onAccountDeleted = onAccountDeleted,
                    )
                }
            }
        }
    }

    if (showBottomSheet) {
        AddFoodBottomSheet(
            onDismiss = { showBottomSheet = false },
            onOptionSelected = { option ->
                when (option) {
                    "Food Database" ->
                        navBackStack.navigateSingleTop(Routes.FoodDatabaseScreen)

                    "Scan Barcode" ->
                        navBackStack.navigateSingleTop(Routes.BarcodeScanScreen)

                    // CHANGED: opens the Saved scans tab
                    "Saved Foods" ->
                        navBackStack.navigateSingleTop(Routes.SavedScansScreen)
                }
            },
        )
    }
}

@RequiresApi(Build.VERSION_CODES.VANILLA_ICE_CREAM)
@Composable
private fun MainContent(
    modifier: Modifier = Modifier,
    navBackStack: NavBackStack<NavKey>,
    onSignedOut: () -> Unit,
    onAccountDeleted: () -> Unit,
) {
    val saveableStateDecorator =
        rememberSaveableStateHolderNavEntryDecorator<NavKey>()

    val viewModelStoreDecorator =
        rememberViewModelStoreNavEntryDecorator<NavKey>()

    val entryDecorators = remember(
        saveableStateDecorator,
        viewModelStoreDecorator
    ) {
        listOf(
            saveableStateDecorator,
            viewModelStoreDecorator
        )
    }

    NavDisplay(
        modifier = modifier.fillMaxSize(),
        entryDecorators = entryDecorators,
        backStack = navBackStack,
        entryProvider = entryProvider {

            entry<Routes.HomeScreen> {
                HomeScreen(
                    onLogFoodClick = {
                        navBackStack.navigateSingleTop(
                            Routes.FoodDatabaseScreen
                        )
                    }
                )
            }

            entry<Routes.ProgressScreen> {
                ProgressScreen()
            }

            entry<Routes.SettingsScreen> {
                SettingsScreen(
                    onPrivacyPolicyClick = {},
                    onTermsClick = {},
                    onRateAppClick = {},
                    onSignedOut = onSignedOut,
                    onAccountDeleted = onAccountDeleted
                )
            }

            entry<Routes.FoodDatabaseScreen> {
                FoodDatabaseScreen(
                    onBack = {
                        navBackStack.removeLastOrNull()
                    }
                )
            }

            // CHANGED: same screen as FoodDatabaseScreen, starting on the Saved scans tab
            entry<Routes.SavedScansScreen> {
                FoodDatabaseScreen(
                    initialTab = FoodTab.SAVED_SCANS,
                    onBack = {
                        navBackStack.removeLastOrNull()
                    }
                )
            }

            entry<Routes.BarcodeScanScreen> {
                BarcodeScanScreen(
                    onBack = {
                        navBackStack.removeLastOrNull()
                    },
                    onLogged = {
                        navBackStack.removeLastOrNull()
                    }
                )
            }
        }
    )
}

