package com.macrivo.app.presentation.mymeal.component

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.macrivo.app.domain.model.MealIngredient
import com.macrivo.app.presentation.commoncomponent.CustomButton
import com.macrivo.app.presentation.commoncomponent.CustomInputField
import com.macrivo.app.presentation.commoncomponent.TopBar
import com.macrivo.app.presentation.ui.theme.ResponsiveAppTheme
import com.macrivo.app.presentation.ui.theme.spacing

@Composable
fun CreateMealScreen(
    modifier: Modifier = Modifier,
    mealName: String,
    totalCal: Float,
    totalProtein: Float,
    totalCarbs: Float,
    totalFat: Float,
    ingredients: Map<String, MealIngredient>,
    hasUnsavedChanges: Boolean = false,
    onMealNameChanged: (String) -> Unit = {},
    onIngredientAdd: () -> Unit = {},
    isEditMode: Boolean = false,
    onSave: () -> Unit = {},
    onDelete: () -> Unit = {},
    onIngredientRemove: (String) -> Unit = {},
    onBack: () -> Unit = {}
) {
    val scrollState = rememberScrollState()

    val saveEnabled =
        !isEditMode || hasUnsavedChanges && mealName.isNotBlank() && ingredients.isNotEmpty() // Always enable for create

    Column(
        modifier = modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .background(MaterialTheme.colorScheme.background)
    ) {

        TopBar(
            heading = if (isEditMode) "Edit Meal" else "Create Meal",
            onBack  = onBack,
            actions = {
                if (isEditMode) {
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete meal",
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            },
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
        ) {

            Text(
                text = " Meal Name",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                ),
                modifier = Modifier.padding(start = MaterialTheme.spacing.md)
            )

            CustomInputField(
                mealName = mealName,
                onMealNameChanged = onMealNameChanged,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = MaterialTheme.spacing.sm, start = MaterialTheme.spacing.md, end = MaterialTheme.spacing.md),
                placeholder = "e.g. Post-Workout Bowl"
            )

            MacroSummarySection(
                modifier = Modifier.padding(
                    top = MaterialTheme.spacing.md,
                    start = MaterialTheme.spacing.md,
                    end = MaterialTheme.spacing.md
                ),
                totalCal = totalCal,
                totalProtein = totalProtein,
                totalCarbs = totalCarbs,
                totalFat = totalFat,
            )

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        top = MaterialTheme.spacing.lg,
                        bottom = 0.dp,
                        start = MaterialTheme.spacing.md,
                        end = MaterialTheme.spacing.md
                    )
            ) {
                Text(
                    text = "MEAL ITEMS",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    ),
                )

                Surface(
                    onClick = onIngredientAdd,
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.xs),
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add item",
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Add Item",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }

            AnimatedVisibility(visible = ingredients.isEmpty()) {
                EmptyIngredientState(
                    modifier = Modifier.padding(
                        top = MaterialTheme.spacing.lg,
                        start = MaterialTheme.spacing.md,
                        end = MaterialTheme.spacing.md
                    ),
                    onAddItem = onIngredientAdd
                )
            }

            AnimatedVisibility(
                visible = ingredients.isNotEmpty(),
                modifier = Modifier
                    .padding(
                        top = MaterialTheme.spacing.lg,
                        start = MaterialTheme.spacing.md,
                        end = MaterialTheme.spacing.md)

            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.sm)
                ) {
                    ingredients.forEach { (key, ingredient) ->
                        IngredientCard(
                            ingredient = ingredient,
                            onRemove = { onIngredientRemove(key) }
                        )
                    }
                }
            }

            CustomButton(
                text = if(isEditMode) "Edit Meal" else "Save Meal",
                onClick = onSave,
                enabled = saveEnabled,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .navigationBarsPadding()
                    .padding(MaterialTheme.spacing.md)
                ,
                buttonColors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                )
            )

        }

    }
}

@Preview
@Composable
private fun PrevCreateMealScreen() {
    ResponsiveAppTheme(darkTheme = true) {
        CreateMealScreen(
            mealName = "mealName",
            onMealNameChanged = {},
            ingredients = mapOf(
                "id" to MealIngredient(
                    foodId = "id",
                    foodName = "Pizza"
                ),
                "id2" to MealIngredient(
                    foodId = "id2",
                    foodName = "Pizza2"
                ),
                "id3" to MealIngredient(
                    foodId = "id3",
                    foodName = "Pizza3"
                )
            ),
            totalCal = 100f,
            totalProtein = 100f,
            totalCarbs = 100f,
            totalFat = 38f,
            onIngredientAdd = {},
            onIngredientRemove = {}
        )
    }
}