package com.macrivo.app.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.macrivo.app.core.utils.DateUtils
import com.macrivo.app.data.mapper.DateSelectionState
import com.macrivo.app.data.mapper.toDatePickerUiState
import com.macrivo.app.domain.model.DailySummary
import com.macrivo.app.domain.model.foodlog.FoodLog
import com.macrivo.app.domain.model.macros.MacroTarget
import com.macrivo.app.domain.use_case.dailysummary.ObserveDailySummaryForDateUseCase
import com.macrivo.app.core.utils.Resource
import com.macrivo.app.domain.use_case.foodlog.DeleteFoodLogUseCase
import com.macrivo.app.domain.use_case.foodlog.GetFoodLogUseCase
import com.macrivo.app.domain.use_case.foodlog.ObserveFoodLogsForDateUseCase
import com.macrivo.app.domain.use_case.foodlog.UpdateFoodLogQuantityUseCase
import com.macrivo.app.domain.use_case.foodlog.ObserveLoggedDatesUseCase
import com.macrivo.app.domain.use_case.macrostarget.GetCurrentMacroTargetUseCase
import com.macrivo.app.domain.use_case.profile.GetUserNameUseCase
import com.macrivo.app.domain.use_case.streak.ObserveStreakStatsUseCase
import com.macrivo.app.presentation.home.mapper.buildStreakWeekUiState
import com.macrivo.app.presentation.home.mapper.toHealthMetricsUiState
import com.macrivo.app.presentation.foodbrowse.FoodDetailMode
import com.macrivo.app.presentation.foodbrowse.FoodDetailUiState
import com.macrivo.app.presentation.home.mapper.toFoodDetailUiState
import com.macrivo.app.presentation.home.mapper.toNutritionUiState
import com.macrivo.app.presentation.home.mapper.toRecentMealsUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import javax.inject.Inject

private data class HomeCoreData(
    val foodLogs: List<FoodLog>,
    val dailySummary: DailySummary?,
    val macroTarget: MacroTarget?,
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val observeDailySummaryForDateUseCase: ObserveDailySummaryForDateUseCase,
    private val observeFoodLogsForDateUseCase: ObserveFoodLogsForDateUseCase,
    private val getCurrentMacroTargetUseCase: GetCurrentMacroTargetUseCase,
    private val observeStreakStatsUseCase: ObserveStreakStatsUseCase,
    private val observeLoggedDatesUseCase: ObserveLoggedDatesUseCase,
    private val getUserName: GetUserNameUseCase,
    private val getFoodLogUseCase: GetFoodLogUseCase,
    private val deleteFoodLogUseCase: DeleteFoodLogUseCase,
    private val updateFoodLogQuantityUseCase: UpdateFoodLogQuantityUseCase,
) : ViewModel() {

    private val today = DateUtils.today()

    private val currentWeekDays = DateUtils.getCurrentWeekDates(
        DateUtils.getWeekStart(today)
    )

    private val _dateState = MutableStateFlow(
        DateSelectionState(
            selectedDate = today,
            weekStartDate = DateUtils.getWeekStart(today),
            weekDays = DateUtils.getCurrentWeekDates(
                DateUtils.getWeekStart(today)
            ),
        )
    )

    private val _state = MutableStateFlow(HomeUiState())
    val state = _state.asStateFlow()


    private val selectedFoodLogId = MutableStateFlow<String?>(null)
    // a save or a delete is running
    private val isDeleting = MutableStateFlow(false)
    private val editedQuantity = MutableStateFlow<Float?>(null)

    /** null = sheet closed. */
    val foodDetail = selectedFoodLogId
        .flatMapLatest { id ->
            if (id == null) {
                flowOf<FoodDetailUiState?>(null)
            } else {
                flow<FoodDetailUiState> {
                    emit(FoodDetailUiState.Loading)

                    val log = runCatching { getFoodLogUseCase(id) }.getOrNull()

                    if (log == null) {
                        emit(FoodDetailUiState.Error("This food entry no longer exists."))
                    } else {
                        emitAll(
                            combine(editedQuantity, isDeleting) { qty, busy ->
                                log.toFoodDetailUiState(
                                    isBusy = busy,
                                    editedQuantity = qty ?: log.quantity,
                                )
                            }
                        )
                    }
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    // One-off messages (e.g. a failed delete) - shown once, not part of the screen state.
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    private val _listMessages = Channel<String>(Channel.BUFFERED)
    val listMessages = _listMessages.receiveAsFlow()

    /**
     * Swipe-to-delete, called after the confirmation dialog. Same use case (and so the same rules:
     * today only, summary updated in the same transaction, Firestore delete synced, never negative)
     * as the Delete button in the details sheet.
     */
    fun onDeleteFoodLogFromList(id: String) {
        viewModelScope.launch {
            val result = deleteFoodLogUseCase(id)
            if (result is Resource.Error) {
                _listMessages.send(result.message ?: "Unable to delete this food.")
            }
        }
    }

    fun onFoodLogClick(id: String) {
        editedQuantity.value = null
        selectedFoodLogId.value = id
    }

    fun onFoodDetailDismiss() {
        if (isDeleting.value) return
        selectedFoodLogId.value = null
        editedQuantity.value = null
    }

    /** Only today's foods are editable; the screen does not offer the stepper for older ones. */
    fun onQuantityChanged(quantity: Float) {
        val detail = foodDetail.value as? FoodDetailUiState.Success ?: return
        if (detail.mode != FoodDetailMode.LOGGED_TODAY || isDeleting.value) return
        editedQuantity.value = quantity
    }

    /**
     * Stores the edited quantity. Room changes (log + daily summary in one transaction), Home re-emits
     * by itself; the sheet closes on success and shows a message on failure.
     */
    fun onSaveFoodLogChanges() {
        val id = selectedFoodLogId.value ?: return
        val detail = foodDetail.value as? FoodDetailUiState.Success ?: return
        val quantity = editedQuantity.value ?: return
        if (detail.mode != FoodDetailMode.LOGGED_TODAY || !detail.hasChanges || isDeleting.value) return

        isDeleting.value = true
        viewModelScope.launch {
            val result = updateFoodLogQuantityUseCase(id, quantity)
            isDeleting.value = false

            if (result is Resource.Error) {
                _messages.send(result.message ?: "Unable to update this food.")
            } else {
                selectedFoodLogId.value = null
                editedQuantity.value = null
            }
        }
    }

    /**
     * Deletes the open food. No Home state is touched here: the delete changes Room (log + daily
     * summary in one transaction), the observed flows re-emit and Home updates by itself.
     */
    fun onDeleteFoodLog() {
        val id = selectedFoodLogId.value ?: return
        val detail = foodDetail.value as? FoodDetailUiState.Success ?: return
        if (detail.mode != FoodDetailMode.LOGGED_TODAY || isDeleting.value) return

        isDeleting.value = true
        viewModelScope.launch {
            val result = deleteFoodLogUseCase(id)
            isDeleting.value = false

            if (result is Resource.Error) {
                _messages.send(result.message ?: "Unable to delete this food.")
            } else {
                selectedFoodLogId.value = null
            }
        }
    }


    /**
     * Every feature that depends on the selected date
     * should observe this flow.
     */
    private val selectedDateFlow =
        _dateState
            .map { it.selectedDate }
            .distinctUntilChanged()

    private val foodLogsFlow =
        selectedDateFlow.flatMapLatest(observeFoodLogsForDateUseCase::invoke)

    private val dailySummaryFlow =
        selectedDateFlow.flatMapLatest(observeDailySummaryForDateUseCase::invoke)

    private val macroTargetFlow =
        flow {
            emit(getCurrentMacroTargetUseCase())
        }

    private val userNameFlow = flow {
        emit(
            runCatching {
                getUserName().orEmpty().trim()
            }.getOrDefault("")
        )
    }

    private val coreDataFlow =
        combine(
            foodLogsFlow,
            dailySummaryFlow,
            macroTargetFlow,
        ) { foodLogs, dailySummary, macroTarget ->
            HomeCoreData(foodLogs, dailySummary, macroTarget)
        }

    init {
        observeHomeState()
    }

    private fun observeHomeState() {
        combine(
            coreDataFlow,
            _dateState,
            observeStreakStatsUseCase(),
            observeLoggedDatesUseCase(),
            userNameFlow,
        ) { core, dateNav, streakStats, loggedDates, userName ->

            HomeUiState(
                isLoading = false,
                userName = userName,
                streak = buildStreakWeekUiState(
                    streakStats = streakStats,
                    loggedDates = loggedDates,
                    currentWeekDays = currentWeekDays,
                    today = today,
                ),
                datePicker = dateNav.toDatePickerUiState(),
                nutrition = core.dailySummary.toNutritionUiState(
                    fallbackTarget = core.macroTarget?.targets,
                ),
                healthMetrics = core.macroTarget.toHealthMetricsUiState(),
                recentMeals = core.foodLogs.toRecentMealsUiState(),
            )
        }.onEach { newState ->
            _state.value = newState
        }.launchIn(viewModelScope)
    }


    fun onDateSelected(date: Long) {
        _dateState.update { current ->

            val weekStart =
                if (DateUtils.isDateInWeek(date, current.weekStartDate)) {
                    current.weekStartDate
                } else {
                    DateUtils.getWeekStart(date)
                }

            current.copy(
                selectedDate = date,
                weekStartDate = weekStart,
                weekDays = DateUtils.getCurrentWeekDates(weekStart),
            )
        }
    }

    fun onPreviousWeek() {
        _dateState.update { current ->
            current.copyForWeek(
                DateUtils.getPreviousWeek(current.weekStartDate)
            )
        }
    }

    fun onNextWeek() {
        _dateState.update { current ->

            if (DateUtils.isCurrentWeek(current.weekStartDate)) {
                return@update current
            }

            current.copyForWeek(
                DateUtils.getNextWeek(current.weekStartDate)
            )
        }
    }


    private fun DateSelectionState.copyForWeek(
        newWeekStart: Long,
    ): DateSelectionState {

        val weekdayIndex =
            DateUtils.getSelectedWeekdayIndex(
                date = selectedDate,
                weekStart = weekStartDate,
            )

        val candidateDate =
            DateUtils.getDateForWeekday(
                weekStart = newWeekStart,
                weekdayIndex = weekdayIndex,
            )

        val resolvedDate =
            if (DateUtils.isFutureDate(candidateDate)) today else candidateDate

        return copy(
            selectedDate = resolvedDate,
            weekStartDate = newWeekStart,
            weekDays = DateUtils.getCurrentWeekDates(newWeekStart),
        )
    }
}
