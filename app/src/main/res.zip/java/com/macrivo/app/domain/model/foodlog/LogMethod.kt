package com.macrivo.app.domain.model.foodlog

enum class LogMethod(val displayName: String) {
    DATABASE("Food Database"),
    BARCODE("Scan Barcode"),
    CAMERA("Scan Food"),
    SAVED("Saved Foods"),
    MANUAL("Manual Entry")
}