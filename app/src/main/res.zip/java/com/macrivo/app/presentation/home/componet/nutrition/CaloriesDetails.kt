package com.macrivo.app.presentation.home.componet.nutrition

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.macrivo.app.presentation.commoncomponent.CustomButton
import com.macrivo.app.presentation.home.model.CaloriesUiModel
import com.macrivo.app.presentation.ui.theme.spacing

@Composable
fun CaloriesDetails(
    modifier: Modifier = Modifier,
    calories: CaloriesUiModel,
    onLogFoodClick: () -> Unit,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(
            MaterialTheme.spacing.sm,
        ),
    ) {

        NutritionInfo(
            consumedText = calories.consumedText,
            targetText = calories.targetText,
            remainingText = calories.remainingText,
        )

        LinearProgress(
            progress = calories.progress,
        )

        CustomButton(
            modifier = Modifier.fillMaxWidth(),
            text = "Log Food",
            imageVector = Icons.Default.Add,
            buttonColors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            onClick = onLogFoodClick,

        )
    }
}