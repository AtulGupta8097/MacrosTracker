package com.macrivo.app.presentation.foodbrowse

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import com.macrivo.app.domain.model.FoodItem
import com.macrivo.app.domain.model.Serving

@Composable
fun FoodBrowsePhoneLayout(
    state: FoodBrowseState,
    foodDetailUiState: FoodDetailUiState,
    onRootChanged: (Boolean) -> Unit,
    onQueryChange: (String) -> Unit,
    onFoodClick: (String) -> Unit,
    onBack: () -> Unit,
    onServingSelected: (Serving) -> Unit,
    onQuantityChanged: (Float) -> Unit,
    onSaveToggle: () -> Unit,
    onLog: () -> Unit,
) {
    val isOnList = state.destination is FoodBrowseDestination.List

    LaunchedEffect(isOnList) { onRootChanged(isOnList) }

    BackHandler(enabled = !isOnList) { onBack() }

    when (state.destination) {
        FoodBrowseDestination.List -> {
            FoodBrowseListScreenImpl(
                query = state.query,
                onQueryChange = onQueryChange,
                data = state.foods,
                isLoading = state.isLoading,
                error = state.error,
                onFoodClick = onFoodClick,
                selectedFoodId = state.selectedFood?.id,
            )
        }

        is FoodBrowseDestination.Detail -> {
            FoodDetailScreen(
                uiState = foodDetailUiState,
                // CHANGED: single onEvent
                onEvent = { event ->
                    when (event) {
                        FoodDetailUiEvent.Back -> onBack()
                        is FoodDetailUiEvent.ServingSelected -> onServingSelected(event.serving)
                        is FoodDetailUiEvent.QuantityChanged -> onQuantityChanged(event.quantity)
                        FoodDetailUiEvent.SaveToggled -> onSaveToggle()
                        FoodDetailUiEvent.LogClicked -> onLog()
                        FoodDetailUiEvent.SaveChangesClicked,
                        FoodDetailUiEvent.DeleteConfirmed -> Unit // browse never shows Delete
                    }
                },
            )
        }
    }
}

@Composable
private fun FoodBrowseListScreenImpl(
    query: String,
    onQueryChange: (String) -> Unit,
    data: List<FoodItem>,
    isLoading: Boolean,
    error: String?,
    onFoodClick: (String) -> Unit,
    selectedFoodId: String? = null,
) {
    FoodBrowseListScreen(
        query = query,
        onQueryChange = onQueryChange,
        data = data,
        isLoading = isLoading,
        error = error,
        onFoodClick = onFoodClick,
        selectedFoodId = selectedFoodId,
    )
}
