package com.macrivo.app.domain.repository

import com.macrivo.app.domain.model.UserProfile
import kotlinx.coroutines.flow.Flow

interface UserProfileRepository {

    fun observeUserProfile(): Flow<UserProfile?>

    suspend fun saveUserProfile(profile: UserProfile)

    suspend fun getUserProfile(): UserProfile?

    suspend fun getUserName(): String?

    suspend fun syncPending()
}
